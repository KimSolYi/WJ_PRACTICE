﻿Public Class Form1
    Public vCompany As SAPbobsCOM.Company
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vCompany = New SAPbobsCOM.Company

        vCompany.Server = "77106153-PC\MSSQLSERVER_2017"
        Debug.Print(vCompany.Server.ToString)
        vCompany.CompanyDB = "SBODemoKR"
        vCompany.UserName = "manager"
        vCompany.Password = "manager"
        vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017

        Dim nResult As Long
        '    Dim strErrString As String

        'Connect to the database
        nResult = vCompany.Connect

        'Display the result
        ' MsgBox("Connected ")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click   'bp마스터를 불러와서 필드 출력
        Dim RetVal As Boolean
        Dim vBP As SAPbobsCOM.BusinessPartners

        vBP = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)

        'Retrieve a record by its key from the database
        RetVal = vBP.GetByKey(TextBox1.Text)

        If RetVal = True Then
            TextBox2.Text = vBP.CardName
            ' vBP.Phone1 = "555-0119"
            TextBox3.Text = vBP.Phone1
            TextBox4.Text = vBP.Address

        End If

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim nErr As Long
        Dim errMsg As String
        Dim vBP As SAPbobsCOM.BusinessPartners


        vBP = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)


        If TextBox5.Text = Nothing Then
            MsgBox("수정할 번호를 입력하세요")


        Else
            'Get the required record of the current object
            If (vBP.GetByKey(TextBox1.Text) = True) Then
                'Update the required properties
                ' vBP.FreeText = "Here's free text"

                vBP.Phone1 = TextBox5.Text

                nErr = vBP.Update

                Debug.Print(nErr.ToString)


            End If
        End If

        'check for errors
        Call vCompany.GetLastError(nErr, errMsg)
        If (0 <> nErr) Then
            MsgBox("Found error:" + Str(nErr) + "," + errMsg)
        End If
    End Sub

  
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim nErr As Long
        Dim errMsg As String
        Dim vBP As SAPbobsCOM.BusinessPartners
        '  Dim vitem As SAPbobsCOM.Items
        Dim RetVal As Long
        vBP = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oBusinessPartners)


        Dim vitem As SAPbobsCOM.Items
        vitem = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
        'Retrieve the record to remove from the database
        RetVal = vitem.GetByKey("A10")
        
        ' If (vBP.GetByKey(TextBox1.Text) = True) Then

        If (RetVal = True) Then
      
            nErr = vitem.Remove()
            If (RetVal = False) Then
                MsgBox("REMOVE 되었다.")
            End If

            Debug.Print(nErr.ToString)
            '


        End If
        '   End If

        ''check for errors
        'Call vCompany.GetLastError(nErr, errMsg)
        'If (0 <> nErr) Then
        '    MsgBox("Found error:" + Str(nErr) + "," + errMsg)
        'End If
    End Sub
End Class
