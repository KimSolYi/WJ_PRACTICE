﻿Public Class Form1
    Private myConn As SqlConnection 'DB 연결 설정
    Private myCmd As SqlCommand '쿼리 실행
    Private myReader As SqlDataReader '쿼리 결과 검색
    Private results As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load     '기본값 세팅
        TextBox1.Text = "TESTDB01"
        TextBox2.Text = "77106153-PC\MSSQLSERVER_2017"
        TextBox3.Text = "SSPI"

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sConStr As String = "Initial Catalog = " & TextBox1.Text & ";Data Source=" & TextBox2.Text & ";Integrated Security=" & TextBox3.Text & ";"    '중요부분1

        If myConn Is Nothing Then
            myConn = New SqlConnection(sConStr) '중요부분2
        End If

        If myConn.State = ConnectionState.Open Then
            MsgBox("이미 연결되었습니다.")

        Else

            MsgBox(sConStr & "으로 연결합니다.")
            myConn.Open()   '중요부분3

            If myConn.State = ConnectionState.Open Then
                MsgBox("연결 성공!")

            Else
                MsgBox("연결 실패!")

            End If
        End If


    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                .CommandText = "SELECT cast(number as  nvarchar(20)), name, cast(createtime as nvarchar(20)) FROM myTable"
            End With
            Try
                myReader = myCmd.ExecuteReader()
                Do While myReader.Read()
                    results = results & myReader.GetString(0) & vbTab & myReader.GetString(1) & vbTab & myReader.GetString(2) & vbLf
                Loop
                MsgBox(results)
                results = ""
            Catch ex As Exception
                MessageBox.Show(ex.Message.ToString(), "Error Message")
            Finally
                results = ""
                myReader.Close()
                myReader = Nothing
            End Try
        End Using
    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                '  .CommandText = "SELECT * FROM OCRD WHERE CardCode = 'V1010' "
                .CommandText = "SELECT * FROM TESTDB01"

            End With

            Try
                myReader = myCmd.ExecuteReader()

                Do While myReader.Read()
                    results = results & myReader.GetString(0) & vbTab & myReader.GetString(1) & vbLf

                Loop
                MsgBox(results)

            Catch ex As Exception

                MessageBox.Show(ex.Message.ToString(), "Error Message")

            Finally '버튼 여러번 눌리는 버그 해결
                results = ""
                If myReader.IsClosed = False Then
                    myReader.Close()
                End If
                myReader = Nothing
            End Try

        End Using
    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim a As Integer
        Dim count1 As Integer
        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                .CommandText = "insert into mytable (number, name, createtime) values (@param1, @param2, @param3)"
                .Parameters.Add("@param1", SqlDbType.Int).Value = count1
                .Parameters.Add("@param2", SqlDbType.NChar, 20).Value = "kb"
                .Parameters.Add("@param3", SqlDbType.Date).Value = "2020-09-28"
                Try
                    a = .ExecuteNonQuery
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString(), "Error Message")
                Finally
                    If count1 <> Nothing Then
                        count1 = count1 + 1
                    Else
                        count1 = 1
                    End If
                End Try

                If a <> -1 Then
                    MessageBox.Show("입력완료", "Info msg")
                Else
                    MessageBox.Show("입력실패", "error msg")
                End If
            End With
        End Using
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim returnVAl As Integer
        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                .CommandText = "Update myTable set name = @param1 from mytable"
                .Parameters.Add("@param1", SqlDbType.Int).Value = "2"
                Try
                    returnVAl = .ExecuteNonQuery
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString, "Error Msg")
                End Try
                If returnVAl <> -1 Then
                    MessageBox.Show("Update Completed", "Info msg")
                Else
                    MessageBox.Show("UPdate Failed", "Error MSG")
                End If
            End With
        End Using
    End Sub

   Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim returnVal As Integer
        Dim inputVal As String
        'If TextBox4.Text <> "" Then
        'inputVal = TextBox4.Text
        ' Else
        inputVal = "NULL"
        ' End If
        Using myCmd As New SqlCommand()
            With myCmd
                .Connection = myConn
                .CommandType = CommandType.Text
                .CommandText = "delete from myTable where name = @param1"
                .Parameters.Add("@param1", SqlDbType.NChar, 20).Value = inputVal
                Try
                    returnVal = .ExecuteNonQuery
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString.ToString, "error Msg")
                    '  Finally
                    '   TextBox4.Text = ""

                End Try
                If returnVal <> -1 Then
                    MessageBox.Show("Delete Completed", "INFO")
                Else
                    MessageBox.Show("Delete failed", "Error")
                End If

            End With
        End Using
    End Sub
End Class
