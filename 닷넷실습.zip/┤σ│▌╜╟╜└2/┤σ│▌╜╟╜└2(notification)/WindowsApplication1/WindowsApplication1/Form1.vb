﻿Public Class Form1
    Public vCompany As SAPbobsCOM.Company
    'Public myConn As SqlConnection 'DB 연결 설정
    'Public myCmd As SqlCommand '쿼리 실행
    'Public myReader As SqlDataReader '쿼리 결과 검색
    'Public results As String

    Public Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        vCompany = New SAPbobsCOM.Company

        'Initialize the Company Object for the Connect method
        


        Debug.Print("dd")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click   'Connect
        'vCompany = New SAPbobsCOM.Company

        ''Initialize the Company Object for the Connect method
        vCompany.Server = "77106153-PC\MSSQLSERVER_2017"
        vCompany.CompanyDB = "SBODemoKR"
        vCompany.UserName = "manager"
        vCompany.Password = "manager"
        vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017

        Dim nResult As Long
        Dim strErrString As String

        'Connect to the database
        nResult = vCompany.Connect

        'Display the result
        MsgBox("result is " + Str(nResult))
        Call vCompany.GetLastError(nResult, strErrString)
        MsgBox("GetLastError(" + Str(nResult) + ", " + strErrString + ")")
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click   'Disconnect

        'On Error GoTo ErrorHandler
        'Dim vCompany As SAPbobsCOM.Company

        ''create company object
        'vCompany = New SAPbobsCOM.Company

        ''set paras for connection
        'vCompany.CompanyDB = "SBODemoKR"
        'vCompany.Password = "manager"
        'vCompany.UserName = "manager"
        'vCompany.Server = "77106153-PC\MSSQLSERVER_2017"
        'vCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017

        'connect to database server
        If vCompany.Connected = False Then '연결된 상태면
            MsgBox("Failed to connect")
        Else
            vCompany.Disconnect()
            MsgBox("Disconnected")
        End If
        Exit Sub

        'do it now


        'Check Error
        Dim nErr As Long
        Dim errMsg As String

        Call vCompany.GetLastError(nErr, errMsg)
        If (0 <> nErr) Then
            MsgBox("Found error:" + errMsg)
        End If

        'disconnect the company object, and release resource

        vCompany = Nothing
        Debug.Print("OK")
        Exit Sub
ErrorHandler:
        MsgBox("Exception:" + Err.Description)


    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click   '조회

        'Dim oRecordSet As SAPbobsCOM.Recordset
        Dim Count As Long
        Dim FldName As String
        Dim FldVal As String
        Dim FldName1 As String
        Dim FldVal1 As String
        Dim i As Integer
        Dim RecSet As SAPbobsCOM.Recordset



        RecSet = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        RecSet.DoQuery("select * from OADM")

        Count = RecSet.Fields.Count
        While RecSet.EoF = False
            'The inner loop runs over all the fields in one record (line) of the table
            For i = 0 To Count - 1
                FldName = RecSet.Fields.Item(i).Name
                FldVal = RecSet.Fields.Item(i).Value
                FldName1 += FldName + " "
                FldVal1 += FldVal + " "
                'Here you can manipulate the data as you want
            Next i
            'Move to the next record
            RecSet.MoveNext()
        End While
        'Debug.Print(FldName1 + vbLf + FldVal1)
        MessageBox.Show(FldName1 + vbLf + FldVal1)
        ''// Get an initialized Recordset object
        'oRecordSet = oCompany.GetBusinessObject(BoRecordset)

        ''// Perform the Select statement
        ''// The query result will be loaded
        ''// into the Recordset object
        ''// This is the most effective way to retrieve data
        'oRecordSet.DoQuery("Select cardcode, cardname from ocrd")

        ''// Access the data

        ''// The Select statement retrieves a record set with two fields
        ''// Place the fields' values in the text boxes
        ''// look at the field object in the Help file
        ''// for more field properties (such as name etc.)
        ''// in this case Field(0).Name will be 'CardCode'

        'oRecordSet.Fields.Item(0).Value()
        'oRecordSet.Fields.Item(0).Name()

        ''// Get the next record

        'If oRecordSet.EOF = False Then
        '    oRecordSet.MoveNext()
        'End If

        ''// Get the previous record

        'If oRecordSet.BoF = False Then
        '    oRecordSet.MovePrevious()
        'End If

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click   '프로시저
        Dim Count As Long
        Dim FldName As String
        Dim FldVal As String
        Dim FldName1 As String
        Dim FldVal1 As String
        Dim i As Integer
        Dim RecSet As SAPbobsCOM.Recordset
        Dim CardCode As String
        Dim ItemCode As String
        Dim DocDate As String
        'RecSet = Form1.vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
        RecSet = vCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)

        '  RecSet.DoQuery("select * from OADM")
        'CardCode = TextBox1.Text
        'ItemCode = TextBox2.Text
        'DocDate = TextBox3.Text
        CardCode = "C710005"
        DocDate = "2010-10-10"
        ItemCode = "6013056"


        If CardCode = "" Or ItemCode = "" Or DocDate = "" Then
            MessageBox.Show("모든 값을 입력하시기바랍니다.")
        Else
            '   RecSet.DoQuery("exec dbo.TEST '" & CardCode & "', '" & ItemCode & "', '" & DocDate & "'")
            RecSet.DoQuery("EXEC [dbo].[TEST] 'C710005', '2010-10-10','6013056'")
            Count = RecSet.Fields.Count
            While RecSet.EoF = False

                'The inner loop runs over all the fields in one record (line) of the table
                For i = 0 To Count - 1
                    FldName = RecSet.Fields.Item(i).Name
                    FldVal = RecSet.Fields.Item(i).Value
                    FldName1 += FldName + " "
                    FldVal1 += FldVal + " "

                    'Here you can manipulate the data as you want
                Next i
                'Move to the next record
                RecSet.MoveNext()
            End While
            'Me.Close()
            MessageBox.Show(FldName1 + vbLf + FldVal1)
        End If

    End Sub



End Class
