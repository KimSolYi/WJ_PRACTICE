USE [SBODemoKR]
GO

/****** Object:  StoredProcedure [dbo].[WJS_SP_EMP]    Script Date: 2020-09-24 ���� 3:30:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

	


--CREATE -> ALTER
ALTER PROCEDURE [dbo].[WJS_SP_EMP]
(
		@GBN	AS	NVARCHAR(10)= 'F'
		,@EMPNM	AS	NVARCHAR(100)
)

AS
BEGIN
		IF @GBN = 'F' --����
		BEGIN
			SELECT	CONVERT(INT, ROW_NUMBER() OVER(ORDER BY U_EMPNO)) AS '#'
					,U_EMPNO
					,U_EMPNM 
					,U_JOINDT
					,U_RETIRDT
					
					,CASE WHEN U_JOINDT <= '2020-12-31' THEN
								[dbo].[WJS_FN_WORKMONTH](U_JOINDT,U_RETIRDT) --AS U_MONTH
						ELSE
							NULL
						END		AS U_MONTH

			FROM EMP
			WHERE U_EMPNM LIKE @EMPNM +'%'  --����� EXEC [WJS_SP_EMP] 'F' ,'CHOI'


		END

		ELSE 
		BEGIN

			UPDATE EMP
			SET
				 U_RETIRDT = DATEADD(YEAR, 10 , U_JOINDT)

	--	SELECT	U_JOINDT
		--		,U_RETIRDT = DATEADD(YEAR,1O,U_JOINDT)
	--	FROM EMP
		END

END



GO


